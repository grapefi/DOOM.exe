//-----------------------------------------------------------------------------
//
// $Id:$
//
// Copyright (C) 1993-1996 by id Software, Inc.
//
// This source is available for distribution and/or modification
// only under the terms of the DOOM Source Code License as
// published by id Software. All rights reserved.
//
// The source is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// FITNESS FOR A PARTICULAR PURPOSE. See the DOOM Source Code License
// for more details.
//
// DESCRIPTION:
//   Duh.
//
//-----------------------------------------------------------------------------

#ifndef __G_GAME__
#define __G_GAME__

#include "d_event.h"
#include "doomdef.h"

//
// GAME
//
void G_DeathMatchSpawnPlayer(int playernum);

void G_InitNew(skill_t skill, int episode, int map);

// Can be called by the startup code or M_Responder.
// A normal game starts at map 1,
// but a warp test can start elsewhere
void G_DeferedInitNew(skill_t skill, int episode, int map);

void G_DeferedPlayDemo(char *demo);

// Can be called by the startup code or M_Responder,
// calls P_SetupLevel or W_EnterWorld.
void G_LoadGame(char *name);

void G_DoLoadGame(void);

// Called by M_Responder.
void G_SaveGame(int slot, char *description);

// @REMOVAL demo entry-point prototypes
// `G_RecordDemo`, `G_BeginRecording`, `G_PlayDemo`, and `G_TimeDemo` were
// removed. wasmdoom never records demos and has no startup-driven demo modes
// (`-record` / `-playdemo` / `-timedemo`); the engine only auto-plays demos
// via the intro attract loop (`G_DeferedPlayDemo` -> `G_DoPlayDemo`).
boolean G_CheckDemoStatus(void);

void G_ExitLevel(void);
void G_SecretExitLevel(void);

// Centralized gamestate setter; emits GAME_STATE_CHANGED on a real transition.
void G_SetGameState(gamestate_t newstate);

void G_WorldDone(void);

void G_Ticker(void);
boolean G_Responder(event_t *ev);

void G_ScreenShot(void);

#endif
//-----------------------------------------------------------------------------
//
// $Log:$
//
//-----------------------------------------------------------------------------
